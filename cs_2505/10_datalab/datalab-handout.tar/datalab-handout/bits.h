// selected puzzles for Spring 2013
int minusOne();
int test_minusOne();
int oddBits();
int test_oddBits();
int copyLSB(int);
int test_copyLSB(int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int rempwr2(int, int);
int test_rempwr2(int, int);
int addOK(int, int);
int test_addOK(int, int);
int ilog2(int);
int test_ilog2(int);
int isPower2(int);
int test_isPower2(int);
