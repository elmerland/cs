Elmer Landaverde
9054-91691

To run program: $ python3 prog01.py
