Elmer Landaverde
PID: 9054-91691

How to run the program:
mzscheme < navigator.rkt

What works what doesn't: My program successfully handles finding nodes that are
located at position in tree (Include the root). It also handles the case where
the desired node doesn't exist. To modify the tree where the search is performed
just change the definition of the path variable
