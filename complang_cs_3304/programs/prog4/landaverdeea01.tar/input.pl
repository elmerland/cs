consult(consult).

greataunt(X, harry).

halt.
