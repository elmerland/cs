#include <stdio.h>
#include <ctype.h>
#include "Q3.h"

int main(int argc, char** argv) {

   char mc = *argv[1];
   if ( Q3(mc) ) {
      printf("%c worked\n", mc);
   }

   return 0;
}

