#ifndef Q1_H
#define Q1_H

int Q3(char s);

#endif

