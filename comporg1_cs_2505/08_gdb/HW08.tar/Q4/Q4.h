#ifndef Q2_H
#define Q2_H

int Q4(int x);

#endif

