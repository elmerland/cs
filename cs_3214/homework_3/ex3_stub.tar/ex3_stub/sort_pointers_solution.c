z[0].next = 0;
