char* getunixname(void)
{
  return "";
}

char* getrealname(void)
{
  return "";
}
