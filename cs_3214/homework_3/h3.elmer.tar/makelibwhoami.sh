#!/bin/sh

gcc -shared -o libwhoami.so -fPIC whoami.c
