#!/bin/bash

gcc -shared -o invisible.so -fPIC readdir.c
