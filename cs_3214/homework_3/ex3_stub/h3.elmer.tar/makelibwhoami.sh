#!/bin/sh

gcc -shared -o libwhoami.so -fPIC libwhoami.c
