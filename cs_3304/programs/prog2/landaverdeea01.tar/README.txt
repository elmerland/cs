ELmer Landaverde
ID: 9054-91691

- Compile the program by running "make" inside the directory.
- Run the program by running "./parser" or alternatively use "make run" to run 
the program using the data inside of "data.txt"